<?php

defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_bahaso_api';
$plugin->version  = 2022060602;
$plugin->requires = 2016052314;
