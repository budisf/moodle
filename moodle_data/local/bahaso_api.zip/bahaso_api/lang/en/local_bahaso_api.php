<?php
$string['pluginname'] = 'Bahaso API Services';
