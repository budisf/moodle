
Download for Mac and Windows or use in the browser
https://www.figma.com/downloads/